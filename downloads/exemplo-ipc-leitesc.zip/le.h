/*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-==-=--==-


  =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
/* ============= Bateria de includes ============ */

#include <sys/types.h>
#include <sys/socket.h>
/*#include <sys/syscall.h>
*/
/*#include <sys/ddi.h>
*/
#include <sys/file.h>
#include <sys/errno.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <sys/resource.h>

/* IPC */
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>


#include <netinet/in.h>
/*
#include <malloc.h>
*/
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <netdb.h>
#include <fcntl.h>

#include <errno.h>
#include <signal.h> 


/* ============= Constantes ===================*/

#define OK 	0
#define ERRO	-1
#define TRUE 	1
#define FALSE 	0

#define USED	1
#define UNUSED	0

#define MANUAL     1
#define AUTO       0


#define MAX_ITEM  10 /* define o tamanho do buffer */

#define NUM_SEM	  4  /* numero de semaforos usados */

#define STRING_TAM 70 /* tamanho maximo de cada linha do estrato */


/* ======= Semaforos que implementam o monitor de Hoare ======= */

#define ExM		1   /* o 0 fica para o futuro... */
#define PodeEscrever	2
#define PodeLer		3

/* constantes representando as operacoes nos semaforos */
#define WAIT -1
#define SIGN +1


/* estrutura de dados que vai ser associada a memooria compartilhada */
/* esta estrutura e dependente da aplicação */
typedef struct shm_type
{
   int Escrevendo;		/* TRUE se houver alguem escrevendo, FALSE se nao houver */
   int Leitores;		/* numero de leitores lendo neste momento */
   int SuspensosEmPodeLer;	/* numero de leitores suspensos no semaforo PodeLer */
   int SuspensosEmPodeEscrever; /* numero de escritores suspensos no semaforo PodeEscrever */
   int count;                   /* contador de linear de transacoes bancarias */
} T_SHM;


/* =========== Arquivos abertos ================= */

#define SHARED_FILE "conta_corrente.dbf"
#define SKEY_FILE "sema_key.key"
#define MKEY_FILE "smem_key.key"
#define ELOG "escritor.log"
#define LLOG "leitor.log"
#define SALDO "saldo.dbf"


/* ============ Variaveis globais =============== */


struct shmid_ds shmid_ds; /* para conter os resultados de smclt */

/* uma union obrigatoria para fazer referencia aos semaforos do array de semaforos */
/* deveria, e acho que tem, ser declarada no .h do IPC, mas não funciona. Então tem que redeclarar */
union semun
{
   int val;
   struct semid_ds *buf;
   ushort * array;
} ;


/*-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-==-=-=-=-=

   Funcoes primitivas implementadas

  =-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-==-=-=-=-=*/



