quit

y
/*-------------------------------------------------------

 Autor: Alexandre Sztajnberg
 Data: 11/12/1992	

 Processo principal cria shared memory e semaforo

----------------------------------------------------------*/

#include "le.h" /* include da aplicacao, com varios outros includes */


void main ()

{
      int i, b;    
  
      key_t chave_memo = 6622;
      key_t chave_sema = 6621;
        
      int memo_comp,  /* id da shared memory */
          sema;       /* id da estrutura de semaforos */

      struct sembuf sops; /* estrutura para operacao de semaforos */

      union semun arg;  /* estrutura para o controle do semaforo */

      int semval;

      struct shmid_ds shmid_ds; /* para conter os resultados de smclt */

      FILE *semf, *smemf; /* arquivos com as chaves de IPC */

      char line [256];

      /* estamos criando novos recursos, portanto: deletar os antigos */

      printf ("CRIA: COE717 - Programacao Tempo Real\n");
      printf ("CRIA: Alexandre Sztajnberg - Setembro/96\n");
      printf ("CRIA: Cria recursos compartilhados IPC / System V\n");
      printf ("CRIA: Semaforos e Memoria Compartilhada\n");
      printf ("=================================================\n");  

      sprintf ( line, "rm %s\n", SKEY_FILE );
      system ( line );
      sprintf ( line, "rm %s\n", MKEY_FILE );
      system ( line );

	/* cria a memoria compartilhada (que sera vista pelo pai e filho */

    for (i = 0; 
         ((memo_comp = shmget (chave_memo, sizeof (T_SHM), (0666 | IPC_CREAT | IPC_EXCL))) == -1);
           i++) 
	{ 
	   printf ("CRIA: Erro na criacao de memoria compartilhada (key = %d)\n", chave_memo);
	   printf ("CRIA: Escolha uma chave alternativa: \n");
	   scanf  ("%li", &chave_memo);

	   if (i == 9) exit (1);
	}
 	
	printf("CRIA: ID shared mem devolvido %d\n",memo_comp);

    /* salva a chave em um arquivo para os processsos poderem pegar o semaforo criado*/

    smemf = fopen (MKEY_FILE, "w");

    fprintf (smemf, "%li", chave_memo);

	/* cria os semaforo */
     
    for (i = 0;
        ((sema = semget (chave_sema, NUM_SEM, (0666 | IPC_CREAT | IPC_EXCL))) == -1);
         i++)
	{
	   printf ("CRIA: Erro na criacao de semaforo (key = %d)\n", chave_sema);
 	   printf ("CRIA: Escolha uma chave alternativa: \n");
	   scanf  ("%li", &chave_sema);

	   /* se deu errado, libera a shared memory e sai */

	   if (i == 9)
	   {
         if (( shmctl (memo_comp, IPC_RMID , &shmid_ds)) == -1) 
	          printf ("CRIA: Erro, nao consegui liberar o shm\n");
         exit (2); 
	   }
    }
	
 	printf("CRIA: ID semaforo devolvido %d\n",sema);
	
        /* salva a chave em um arquivo */

    semf = fopen (SKEY_FILE, "w");

    fprintf (semf, "%li", chave_sema);

	/* inicia os semaforos com os valores apropriados */

    /* simula a marcacao inicial da Rede Condicao/Acao */
           
    arg.val = 1; 
    printf ("CRIA: Iniciando semaforo ExM com 1\n");        
    semctl (sema, ExM, SETVAL, arg); /* inicializa a exclusao mutua com 1 */

    arg.val = 0;
    printf ("CRIA: Iniciando semaforo PodeEscrever com 0\n");        
    semctl (sema, PodeEscrever, SETVAL, arg ); /* inicializa semaforos de Escritores com 1 */

    printf ("CRIA: Iniciando semaforo PodeLer com 0\n");        
    semctl (sema, PodeLer, SETVAL, arg  ); /* inicializa semaforos de Leitores com 1 */
        
}


