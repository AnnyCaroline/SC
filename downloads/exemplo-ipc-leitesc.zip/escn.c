/*

 Autor: Alexandre Sztajnberg
 Data: 28/08/96	

 AS: em 30/8 ja funciona o esquema de memoria compartilhada com struct
     os mecanismos de abertura de shm e sem ja funcionam
     parece que o P e V no semaforo nao estao funcionando VERIFICAR !


*/


#include "le.h"

void print_status (int sema, T_SHM *shmem);

void log (FILE *log, int sema, T_SHM *shmem);


void main ()

{
  int j,i,k,t;      
  
  key_t chave_memo;
  key_t chave_sema;  

  int  memo_comp, 
       sema;

  struct sembuf sops;
  int semval;

  T_SHM *shmem;	/* variavel que aponta para a area de memoria compartilhada */

  char path[30];   /* possivel string com o path do arquivo - nao deve ser necessario */
  char buf[STRING_TAM + 1];    /* buffer onde sera transcrita a transacao bancaria antes de gravar */
  int nbyte;       /* numero de bytes a serem gravados */
  int wbyte, rbyte;       /* numero de bytes gravado */
  FILE *fd;          /* descritor do arquivo comum a ser escrito/lido */

  FILE *semf, *smemf; /* arquivos com as chaves de IPC */

  union semun arg;  /* estrutura para o controle do semaforo */

  char modo, pross;   /* inica o modo manual ou automatico de execucao */
  int bmode;



  char fim;           /* inica o modo manual ou automatico de execucao */
  int bfim = FALSE;

  struct timeval  temp;	/* hora instantanea local */

  unsigned long   tnow;

  FILE *esclog; /* arquivo de log do escritor */
  FILE *sald;

  int deposito = 10; /* valor a ser depositado */
  int saldo;


      printf ("ESCR: COE717 - Programacao Tempo Real\n");
      printf ("ESCR: Alexandre Sztajnberg - Setembro/96\n");
      printf ("ESCR: Programa implementando Escritor\n");
      printf ("ESCR: Semaforos e Memoria Compartilhada\n");
      printf ("========================================\n");  



/*
  printf ("ESCR: chave da memoria compartilha: \n");
  scanf  ("%li", &chave_memo);

  printf ("ESCR: chave do semaforo: \n");
  scanf  ("%li", &chave_sema);
*/

    printf ("ESCR: Execucao manual ou automatica: [m/a] \n");
    scanf  ("%c", &modo);

    if (modo == 'm') bmode = MANUAL;
    else bmode = AUTO;


   /* le as chaves nos arquivos */

    smemf = fopen (MKEY_FILE, "r");

    fscanf (smemf, "%li", &chave_memo);

    semf = fopen (SKEY_FILE, "r");

    fscanf (semf, "%li", &chave_sema);

    esclog = fopen (ELOG, "w");

    fprintf (esclog, "Escritor =====> Inicio da execucao \n");


   /* pede acesso a memoria compartilhada */
         
   if ((memo_comp = shmget (chave_memo, sizeof (T_SHM), 0666)) == ERRO)
	printf ("ESCR: Erro no acesso da memoria compartilhada (key = %d)\n", chave_memo); 
   else	
	printf("ESCR: ID shared mem devolvido %d\n",memo_comp);

   /* pede acesso aos semaforo */
     
   if ((sema = semget (chave_sema, NUM_SEM, 0666)) == ERRO)
	printf ("ESCR: Erro no acesso aos semaforos (key = %d)\n", chave_sema);
   else
	printf("ESCR: ID semaforo devolvido %d\n",sema);

   /* nao estou tratando se alguma coisa deu errado */


      
  printf ("ESCR: Iniciando escritor... \n");

  printf("ESCR: ID do semaforo do ESCRITOR  %d\n",sema);
  printf("ESCR: ID shared mem devolvido ESCRITOR %d\n",memo_comp);
  
  /* Agora, attacha / associa a memoria compartilhada ao ponteiro para a esctrutura de dados */

  shmem = shmat (memo_comp, NULL, 0666);
  printf ("ESCR: Ponteiro para semaforo ESCRITOR %d\n", shmem);

  for (j = 0; ((j < 50) && (bfim == FALSE)); j++)
  {

/* =============== Comeca a Escrever =========================== */

     printf ("ESCR: !!!! Comeca a Escrever !!!!\n");

     if (bmode == MANUAL)
     {
        printf ("ESCR: ATENCAO ! Prossegue [s/n] ? \n");
        scanf ("%c", &pross);
     }

     /* wait (ExM) */

     sops.sem_num = ExM;
     sops.sem_op = WAIT;

     if (( semop (sema, &sops, 1)) == ERRO) 
	printf ("ESCR: Erro na operacao wait (ExM)\n");
     else
	printf ("ESCR: Operacao wait (ExM) no semaforo OK\n");

print_status (sema, shmem);
log (esclog, sema, shmem);


      t=rand (); for (i = 0; i < (t * (j % 10)); i++);

     if ((shmem -> Escrevendo == TRUE) || (shmem -> Leitores > 0))
     {
        shmem -> SuspensosEmPodeEscrever++;

print_status (sema, shmem);
log (esclog, sema, shmem);

        /* signal (ExM) */

        sops.sem_num = ExM;
        sops.sem_op = SIGN;

        if (( semop (sema, &sops, 1)) == ERRO) 
	   printf ("ESCR: Erro na operacao wait (ExM)\n");
        else
	   printf ("ESCR: Operacao wait (ExM) no semaforo OK\n");

print_status (sema, shmem);
log (esclog, sema, shmem);

	/* wait (PodeEscrever) */

        sops.sem_num = PodeEscrever;
        sops.sem_op = WAIT;

        if (( semop (sema, &sops, 1)) == ERRO) 
	   printf ("ESCR: Erro na operacao wait (PodeEscrever)\n");
        else
	   printf ("ESCR: Operacao wait (PodeEscrever) no semaforo OK\n");
   
   /* escreve direto no "campo"/variavel em memória compartilhada

        shmem -> SuspensosEmPodeEscrever--; 
     
        shmem ->  Escrevendo = TRUE;

print_status (sema, shmem);
log (esclog, sema, shmem);

        /* signal (ExM) */ /* !!!!!!!!! */

        sops.sem_num = ExM;
        sops.sem_op = SIGN;

        if (( semop (sema, &sops, 1)) == ERRO) 
	   printf ("ESCR: Erro na operacao wait (ExM)\n");
        else
	   printf ("ESCR: Operacao wait (ExM) no semaforo OK\n");

print_status (sema, shmem);
log (esclog, sema, shmem);

     }
     else
     {
        shmem ->  Escrevendo = TRUE;

        /* signal (ExM) */ /* !!!!!!!!! */

        sops.sem_num = ExM;
        sops.sem_op = SIGN;

        if (( semop (sema, &sops, 1)) == ERRO) 
	   printf ("ESCR: Erro na operacao wait (ExM)\n");
        else
	   printf ("ESCR: Operacao wait (ExM) no semaforo OK\n");
     }

/*===================== status ===================*/
     printf (" Escrevendo %s ||", shmem -> Escrevendo == TRUE ? "TRUE ": "FALSE"); 
     printf (" Leitores %d ||", shmem -> Leitores);
     printf (" SuspensosEmPodeLer %d ||",shmem -> SuspensosEmPodeLer);
     printf (" SuspensosEmPodeEscrever %d ", shmem -> SuspensosEmPodeEscrever);
       
     /* semctl (sema, ExM, GETVAL );*/ /* pega os valores */
     printf (" ExM %d ||", /*arg.val*/semctl (sema, ExM, GETVAL ));
        
     /* semctl (sema, PodeEscrever, GETVAL );*/ /* pega os valores */
     printf (" PodeEscrever %d ||", semctl (sema, PodeEscrever, GETVAL ));

       
     /* semctl (sema, PodeLer, GETVAL  ); *//* pega os valores */    
     printf (" PodeLer %d \n", semctl (sema, PodeLer, GETVAL ));

/*======================= status =====================*/



     printf ("ESCR: !!!! Fim: Comeca a Escrever !!!!\n");

   /* fim Comeca Escrever */


/* ================= Escrevendo ====================== */

	printf ("ESCR: !!!! escrevendo ... !!!!\n");

	/* !!!!!!!!!! transcerver o lancamento para o buf, sabendo quantos bytes */

	/* memset (buf, '\n', STRING_TAM + 1); */
	 memset (buf, ' ', STRING_TAM + 1); 
   

        if (bmode == MANUAL)
        {
           printf ("ESCR: Por favor, entre com a quantia a ser depositada:");
           scanf ("%li", &deposito);
        }

        /* pega data e hora local para imprimir tambem */

	gettimeofday(&temp, (struct timezone *)0);
	tnow = (unsigned)(temp.tv_sec*1000000)+(unsigned)temp.tv_usec;
	printf("ESCR: iniciando transacao em %u\n", tnow);
        printf("ESCR  DATA %s\n", ctime(&(temp.tv_sec)));

	 
        sprintf (buf, "Transacao numero (%d): deposito de %d,00 ", j, saldo);
        strcat (buf,  ctime(&(temp.tv_sec)), 23);
        

	/* printf ("ESCR: parametros path=%s, nbyte=%d\n", path, nbyte); */

	/* if ((fd = open (SHARED_FILE, O_WRONLY | O_APPEND)) < 0) */
        if ((fd = fopen (SHARED_FILE, "a")) < 0)
	{
		printf ("ESCR_debug: nao consegui fazero o OPEN...\n");

	}
	else
	/* if ((wbyte = write (fd, buf, STRING_TAM + 1)) < 0) */
        if ((wbyte = fprintf (fd,"Transacao numero (%d): deposito de 10,00 em %s", j, ctime(&(temp.tv_sec))) ) < 0)
	{
		printf ("ESCR: nao consegui fazero o WRITE...\n      %s\n", buf);

		fclose (fd);
	}
	else 
        if ((sald = fopen (SALDO, "r")) < 0)
	{
	   printf ("ESCR_debug: nao consegui fazero o OPEN para saldo...\n");

	}
        if ((rbyte = fscanf (fd, "%li", &saldo)) < 0)
	{
           printf ("LEIT_debug: nao consegui fazero o READ...\n");
	
           fclose (sald);
        }
        else
	{
                /* !!!!!!!!!!! mostra na tela os lancamentos */

                /* calcula o novo saldo */
                saldo = saldo + deposito;
                fclose (sald);

                if ((sald = fopen (SALDO, "w")) < 0)
	        { 
	            printf ("ESCR_debug: nao consegui fazero o OPEN para saldo...\n");

          	}
                if ((rbyte = fprintf (fd, "%li", saldo)) < 0)
	        {
                     printf ("LEIT_debug: nao consegui fazero o WRITE no saldo ...\n");
	
                     fclose (sald);
                }
                
                printf ("ESCR: lancamento (%d) feito WRITE...\n", j);

		/* incrementa o contador de memoria compartilhada */

                 shmem -> count++;

                 fprintf (stderr,"Escritor saida do processo contador = %d\n", shmem ->count);

		/* close (fd); */
                 fclose (fd);
	}
	
	printf ("ESC: transacao terminada. Status = %d\n", wbyte);

	printf ("ESCR: !!!! Fim: escrevendo ... !!!!\n");

        if (bmode == MANUAL)
        {
           printf ("ESCR: ATENCAO ! Prossegue [s/n] ? \n");
           scanf ("%c", &pross);
        }
	

/* fim Escrevendo */

/* =========== Acaba Escrever ==========================*/

     printf ("ESCR: !!!! Acaba Escrever !!!!\n");

print_status (sema, shmem);
log (esclog, sema, shmem);


   /* wait (ExM) */

     sops.sem_num = ExM;
     sops.sem_op = WAIT;

     if (( semop (sema, &sops, 1)) == ERRO) 
	printf ("ESCR: Erro na operacao wait (ExM)\n");
     else
	printf ("ESCR: Operacao wait (ExM) no semaforo OK\n");

print_status (sema, shmem);
log (esclog, sema, shmem);


     t=rand (); for (i = 0; i < (t *  (j % 10)); i++);

     shmem ->  Escrevendo = FALSE;

     if (shmem -> SuspensosEmPodeLer > 0) 
     {

print_status (sema, shmem);
log (esclog, sema, shmem);

        /* signal (PodeLer) */ /* !!!!!!!!! */

        sops.sem_num = PodeLer;
        sops.sem_op = SIGN;

        if (( semop (sema, &sops, 1)) == ERRO) 
	   printf ("ESCR: Erro na operacao wait (PodeLer)\n");
        else
	   printf ("ESCR: Operacao wait (PodeLer) no semaforo OK\n");

print_status (sema, shmem);
log (esclog, sema, shmem);

     }     
     else if (shmem -> SuspensosEmPodeEscrever > 0)
     {
        /* signal (PodeEscrever) */ /* !!!!!!!!! */

        sops.sem_num = PodeEscrever;
        sops.sem_op = SIGN;

        if (( semop (sema, &sops, 1)) == ERRO) 
	   printf ("ESCR: Erro na operacao wait (PodeEscrever)\n");
        else
	   printf ("ESCR: Operacao wait (PodeEscrever) no semaforo OK\n");

print_status (sema, shmem);
log (esclog, sema, shmem);


     }
     else
     {
        /* signal (ExM) */ /* !!!!!!!!! */

        sops.sem_num = ExM;
        sops.sem_op = SIGN;

        if (( semop (sema, &sops, 1)) == ERRO) 
	   printf ("ESCR: Erro na operacao wait (ExM)\n");
        else
	   printf ("ESCR: Operacao wait (ExM) no semaforo OK\n");

print_status (sema, shmem);
log (esclog, sema, shmem);


     } /* fim Acaba Escrever */

     printf ("ESCR: !!!! Fim: Acaba Escrever !!!!\n");

     if (bmode == MANUAL)
     {
       printf ("ESCR: Atencao: mais uma transacao ?: [s/n] \n");
       scanf  ("%c", &fim);

       if (fim == 'n') bfim = TRUE;
       else bfim = FALSE;
     }


     if (bmode == MANUAL)
     {
       printf ("ESCR: Chavear execucao manual ou automatica: [m/a] \n");
       scanf  ("%c", &modo);
 
       if (modo == 'm') bmode = MANUAL;
       else bmode = AUTO;
     }

  } /* fim for */

   printf ("ESCR: !!!! Liberando recursos IPC !!!!\n");

    fprintf (esclog, "Escritor =====> Fim da execucao \n");

   fclose (esclog);

   shmdt ((void *)shmem);

   exit (0);
}

void print_status (int sema, T_SHM *shmem)
{

     printf (" Escrevendo %s ||", shmem -> Escrevendo == TRUE ? "TRUE ": "FALSE"); 
     printf (" Leitores %d ||", shmem -> Leitores);
     printf (" SuspensosEmPodeLer %d ||",shmem -> SuspensosEmPodeLer);
     printf (" SuspensosEmPodeEscrever %d ", shmem -> SuspensosEmPodeEscrever);
       
     /* semctl (sema, ExM, GETVAL );*/ /* pega os valores */
     printf (" ExM %d ||", /*arg.val*/semctl (sema, ExM, GETVAL ));
        
     /* semctl (sema, PodeEscrever, GETVAL );*/ /* pega os valores */
     printf (" PodeEscrever %d ||", semctl (sema, PodeEscrever, GETVAL ));

       
     /* semctl (sema, PodeLer, GETVAL  ); *//* pega os valores */    
     printf (" PodeLer %d \n", semctl (sema, PodeLer, GETVAL ));

}

void log (FILE *log, int sema, T_SHM *shmem)
{

  struct timeval  temp;	/* hora instantanea local */

  unsigned long   tnow;

      gettimeofday(&temp, (struct timezone *)0);
      tnow = (unsigned)(temp.tv_sec*1000000)+(unsigned)temp.tv_usec;


     fprintf (log, " Escrevendo %s || Leitores %d || SuspensosEmPodeLer %d || SuspensosEmPodeEscrever %d || ExM %d || PodeEscrever %d || PodeLer %d  => %s", 
     
      shmem -> Escrevendo == TRUE ? "TRUE ": "FALSE",
      shmem -> Leitores, 
      shmem -> SuspensosEmPodeLer,
      shmem -> SuspensosEmPodeEscrever,
       
      semctl (sema, ExM, GETVAL ),
        
      semctl (sema, PodeEscrever, GETVAL ),
            
      semctl (sema, PodeLer, GETVAL ),
      ctime(&(temp.tv_sec)));

}
